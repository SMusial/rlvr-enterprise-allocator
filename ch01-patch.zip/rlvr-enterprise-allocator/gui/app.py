import streamlit as st

st.set_page_config(
    page_title="RLVR Enterprise Allocator",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

CHAPTERS = {
    "Ch01 — ASP Dispatch (MDP + ε-greedy)":      "ch01",
    "Ch02 — Discrete MDP & Bellman":             "stub",
    "Ch03 — Multi-Armed Bandits":                "stub",
    "Ch04 — Dynamic Programming":                "stub",
    "Ch05 — Monte Carlo Methods":                "stub",
    "Ch06 — Q-Learning":                         "stub",
    "Ch07 — SARSA & On-Policy TD":               "stub",
    "Ch08 — Eligibility Traces":                 "stub",
    "Ch09 — Policy Gradient":                    "stub",
    "Ch10 — Model-Based RL (Dyna)":              "stub",
    "Ch11 — Multi-Agent Foundations":            "stub",
    "Ch12 — Nash Equilibria":                    "stub",
    "Ch13 — Cooperative MARL":                   "stub",
    "Ch14 — Competitive MARL":                   "stub",
    "Ch15 — Deep RL (burn DQN)":                 "stub",
    "Ch16 — Actor-Critic (burn A2C)":            "stub",
    "Ch17 — PPO (burn)":                         "stub",
    "Ch18 — QMIX Multi-Agent Deep RL":           "stub",
    "Ch19 — Federated RL + Privacy":             "stub",
    "Ch20 — PyO3 Interop & Production":          "stub",
}

with st.sidebar:
    st.image("https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Ericsson_logo.svg/320px-Ericsson_logo.svg.png", width=120)
    st.markdown("## RLVR Enterprise Allocator")
    st.markdown("*Reinforcement Learning via Rust*")
    st.markdown("---")
    chapter = st.selectbox("Select Chapter", list(CHAPTERS.keys()))

key = CHAPTERS[chapter]

if key == "ch01":
    from chapters.ch01 import render_ch01
    render_ch01()
else:
    st.info(f"🚧 **{chapter}** — coming soon. Implement Ch01 first to unlock the pattern.")
    st.markdown("Progress: **1 / 20** chapters complete")
    progress = list(CHAPTERS.keys()).index(chapter)
    st.progress(progress / 20)
