"""
Chapter 01 — ASP Field Service Dispatch (Warsaw)
ALL RL logic lives in Rust (rlvr_py). This file is UI only.
"""

import streamlit as st
import json

# ── Rust engine — HARD REQUIREMENT ───────────────────────────────────────────
try:
    import rlvr_py
except ImportError:
    st.error(
        "## ⚙️ Rust engine not found\n\n"
        "This demo requires the compiled Rust extension.\n\n"
        "**Run this once in your terminal:**\n"
        "```bash\n"
        "cd rlvr-py\n"
        "maturin develop\n"
        "```\n"
        "Then refresh this page."
    )
    st.stop()

import plotly.graph_objects as go

try:
    import pydeck as pdk
    HAS_PYDECK = True
except ImportError:
    HAS_PYDECK = False

# ── Theory content EN / PL ────────────────────────────────────────────────────
# Pure UI / educational content — no RL logic here
THEORY = {
    "en": {
        "mdp": {
            "title": "📐 §1.1  The MDP Framework",
            "summary": (
                "The agent-environment interaction is formalized as the **5-tuple (S, A, P, R, γ)**. "
                "At each step t the agent observes state **Sₜ ∈ S**, takes action **Aₜ ∈ A**, "
                "receives reward **Rₜ ∈ ℝ**, and transitions to **Sₜ₊₁** with probability "
                "**P(Sₜ₊₁|Sₜ, Aₜ)**. The **Markov property** guarantees the future depends "
                "*only* on the current state and action — never on history before t.\n\n"
                "In our demo: **S** = {technician positions/skills, open work orders}, "
                "**A** = {assign tech i to order j}, **R** = dispatch quality score."
            ),
            "equation": r"P(s_{t+1}\,|\,s_t,a_t,\,s_{t-1},a_{t-1},\ldots) \;=\; P(s_{t+1}\,|\,s_t,a_t)",
            "book_ref": "📖  Read §1.1 — Fundamentals of Reinforcement Learning",
            "code_ref": "🦀  `AspState` · `AspAction` · `AspEnvironment::reset()` in `ch01_asp_dispatch.rs`",
        },
        "epsilon_greedy": {
            "title": "🎲 §1.1  ε-Greedy Policy",
            "summary": (
                "The **exploration-exploitation dilemma**: with probability **ε** choose a random "
                "action (explore), with probability **1−ε** choose **argmax Q(s,a)** (exploit).\n\n"
                "ε decays from 1.0 → 0.1 over episodes. **Key insight for Ch01**: because the "
                "Q-table is all zeros, 'exploit' also behaves randomly — the agent is completely "
                "blind. Move the ε slider and notice nothing changes yet. "
                "That changes in **Chapter 02** when Bellman updates fill the Q-table."
            ),
            "equation": r"a_t = \begin{cases} \text{random action} & \text{with prob } \varepsilon \\ \arg\max_{a}\,Q(s_t,a) & \text{with prob } 1-\varepsilon \end{cases}",
            "book_ref": "📖  Read §1.1 — Exploration vs. Exploitation Dilemma",
            "code_ref": "🦀  `epsilon_greedy(q_table, state, epsilon, rng)` in `ch01_asp_dispatch.rs`",
        },
        "gt": {
            "title": "📊 §1.1  Discounted Return Gₜ",
            "summary": (
                "The agent's objective is to maximise **expected cumulative discounted reward**. "
                "γ = 0.95 means a reward 20 steps ahead is worth γ²⁰ ≈ 36% of an immediate reward.\n\n"
                "Gₜ is computed **backwards** from episode end — each step's value includes all "
                "future rewards. In the Glass-Box the Gₜ column shows how much total value flows "
                "from that dispatch decision onward.\n\n"
                "The learning curve shows Gₜ₀ per episode — in Ch01 it fluctuates randomly. "
                "It climbs in **Chapter 02**."
            ),
            "equation": r"G_t \;=\; \sum_{k=0}^{\infty}\gamma^k R_{t+k} \;=\; R_t + \gamma R_{t+1} + \gamma^2 R_{t+2} + \cdots",
            "book_ref": "📖  Read §1.1 — Returns, Episodes and the Discount Factor",
            "code_ref": "🦀  `discounted_return(&rewards, GAMMA)` in `ch01_asp_dispatch.rs`",
        },
        "ndarray": {
            "title": "🗂️ §1.2.1  ndarray Q-Table (untrained)",
            "summary": (
                "Q(s, a) stores the **expected discounted return** for taking action a in state s. "
                "In Rust it is `Array2::<f64>::zeros((n_techs, n_orders))` — a matrix where "
                "rows = technicians, columns = work orders.\n\n"
                "**All zeros in Ch01** — this is the unlearned agent's blank slate. "
                "Chapter 02 introduces the Bellman update:\n\n"
                "Q(s,a) ← Q(s,a) + α[R + γ·maxQ(s′,a′) − Q(s,a)]\n\n"
                "that fills this table with real dispatch wisdom over episodes."
            ),
            "equation": r"Q \in \mathbb{R}^{|\text{techs}|\,\times\,|\text{orders}|}, \quad Q[i][j] = 0\;\forall i,j \quad(\text{Ch01 — untrained})",
            "book_ref": "📖  Read §1.2.1 — The ndarray Crate for Tabular RL",
            "code_ref": "🦀  `Array2::<f64>::zeros((n_techs, n_orders))` in `AspEnvironment::new()`",
        },
        "reward": {
            "title": "💰 §1.1  Reward Design R(s,a)",
            "summary": (
                "The reward function is the **compass** guiding the agent. Well-designed rewards "
                "align behavior with business KPIs; poorly designed ones cause *reward hacking*.\n\n"
                "Our ASP reward:\n"
                "- **+10** SLA met + skill match\n"
                "- **+1** SLA met, skill mismatch (−2 penalty)\n"
                "- **−5** SLA breach\n"
                "- **−7** SLA breach + skill mismatch\n\n"
                "Distance proxy: travel time = distance_km / 60 km/h. "
                "If travel time > SLA hours → breach."
            ),
            "equation": r"R(s,a) = \begin{cases} +10 & \text{SLA met, skill match} \\ +1 & \text{SLA met, skill mismatch} \\ -5 & \text{SLA breach, skill match} \\ -7 & \text{SLA breach, skill mismatch} \end{cases}",
            "book_ref": "📖  Read §1.1 — The Reward Signal and Reward Hypothesis",
            "code_ref": "🦀  `reward(state, action)` in `ch01_asp_dispatch.rs`",
        },
    },
    "pl": {
        "mdp": {
            "title": "📐 §1.1  Framework MDP",
            "summary": (
                "Interakcja agenta ze środowiskiem jest sformalizowana jako **5-krotka (S, A, P, R, γ)**. "
                "W każdym kroku t agent obserwuje stan **Sₜ ∈ S**, podejmuje akcję **Aₜ ∈ A**, "
                "otrzymuje nagrodę **Rₜ ∈ ℝ** i przechodzi do **Sₜ₊₁** z prawdopodobieństwem "
                "**P(Sₜ₊₁|Sₜ, Aₜ)**. **Własność Markowa** gwarantuje, że przyszłość zależy "
                "*wyłącznie* od bieżącego stanu i akcji — nigdy od historii przed t.\n\n"
                "W demo: **S** = {pozycje/umiejętności techników, otwarte zlecenia}, "
                "**A** = {przypisz technika i do zlecenia j}, **R** = ocena jakości dyspozycji."
            ),
            "equation": r"P(s_{t+1}\,|\,s_t,a_t,\,s_{t-1},a_{t-1},\ldots) \;=\; P(s_{t+1}\,|\,s_t,a_t)",
            "book_ref": "📖  Czytaj §1.1 — Podstawy Uczenia przez Wzmacnianie",
            "code_ref": "🦀  `AspState` · `AspAction` · `AspEnvironment::reset()` w `ch01_asp_dispatch.rs`",
        },
        "epsilon_greedy": {
            "title": "🎲 §1.1  Polityka ε-Zachłanna",
            "summary": (
                "**Dylemat eksploracji i eksploatacji**: z prawdopodobieństwem **ε** wybierz losową "
                "akcję (eksploracja), z prawdopodobieństwem **1−ε** wybierz **argmax Q(s,a)** "
                "(eksploatacja).\n\n"
                "ε maleje od 1,0 → 0,1 wraz z kolejnymi epizodami. **Kluczowa obserwacja dla Rozdz. 1**: "
                "ponieważ tablica Q jest zerowa, 'eksploatacja' również zachowuje się losowo — "
                "agent jest kompletnie ślepy. To zmienia się w **Rozdziale 2**, gdy aktualizacje "
                "Bellmana wypełnią tablicę."
            ),
            "equation": r"a_t = \begin{cases} \text{losowa akcja} & \text{z prawdopod. } \varepsilon \\ \arg\max_{a}\,Q(s_t,a) & \text{z prawdopod. } 1-\varepsilon \end{cases}",
            "book_ref": "📖  Czytaj §1.1 — Dylemat Eksploracji i Eksploatacji",
            "code_ref": "🦀  `epsilon_greedy(q_table, state, epsilon, rng)` w `ch01_asp_dispatch.rs`",
        },
        "gt": {
            "title": "📊 §1.1  Zdyskontowany Zwrot Gₜ",
            "summary": (
                "Celem agenta jest maksymalizacja **oczekiwanej skumulowanej zdyskontowanej nagrody**. "
                "γ = 0,95 oznacza, że nagroda 20 kroków w przyszłości jest warta γ²⁰ ≈ 36% "
                "nagrody natychmiastowej.\n\n"
                "Gₜ jest obliczane **wstecz** od końca epizodu. W Glass-Box kolumna Gₜ pokazuje "
                "całkowitą wartość płynącą z danej decyzji dyspozycji.\n\n"
                "Krzywa uczenia pokazuje Gₜ₀ na epizod — w Rozdz. 1 fluktuuje losowo. "
                "Wzrasta w **Rozdziale 2**."
            ),
            "equation": r"G_t \;=\; \sum_{k=0}^{\infty}\gamma^k R_{t+k} \;=\; R_t + \gamma R_{t+1} + \gamma^2 R_{t+2} + \cdots",
            "book_ref": "📖  Czytaj §1.1 — Zwroty, Epizody i Współczynnik Dyskontowania",
            "code_ref": "🦀  `discounted_return(&rewards, GAMMA)` w `ch01_asp_dispatch.rs`",
        },
        "ndarray": {
            "title": "🗂️ §1.2.1  Tablica Q ndarray (niewyuczona)",
            "summary": (
                "Q(s, a) przechowuje **oczekiwany zdyskontowany zwrot** za podjęcie akcji a w stanie s. "
                "W Rust: `Array2::<f64>::zeros((n_techs, n_orders))` — macierz gdzie "
                "wiersze = technicy, kolumny = zlecenia.\n\n"
                "**Wszystkie zera w Rozdz. 1** — to pusta tablica niewyuczonego agenta. "
                "Rozdział 2 wprowadza aktualizację Bellmana:\n\n"
                "Q(s,a) ← Q(s,a) + α[R + γ·maxQ(s′,a′) − Q(s,a)]\n\n"
                "która wypełnia tablicę wiedzą o dyspozycji."
            ),
            "equation": r"Q \in \mathbb{R}^{|\text{techs}|\,\times\,|\text{orders}|}, \quad Q[i][j] = 0\;\forall i,j \quad(\text{Rozdz.1 — niewyuczona})",
            "book_ref": "📖  Czytaj §1.2.1 — Biblioteka ndarray dla Tabelarycznego RL",
            "code_ref": "🦀  `Array2::<f64>::zeros((n_techs, n_orders))` w `AspEnvironment::new()`",
        },
        "reward": {
            "title": "💰 §1.1  Projektowanie Nagrody R(s,a)",
            "summary": (
                "Funkcja nagrody to **kompas** prowadzący agenta. Dobrze zaprojektowane nagrody "
                "wyrównują zachowanie z KPI biznesowymi; źle zaprojektowane powodują *reward hacking*.\n\n"
                "Nagroda ASP:\n"
                "- **+10** SLA spełnione + dopasowanie umiejętności\n"
                "- **+1** SLA spełnione, niedopasowanie umiejętności (kara −2)\n"
                "- **−5** naruszenie SLA\n"
                "- **−7** naruszenie SLA + niedopasowanie umiejętności\n\n"
                "Proxy odległości: czas przejazdu = odległość_km / 60 km/h."
            ),
            "equation": r"R(s,a) = \begin{cases} +10 & \text{SLA OK, umiejętności OK} \\ +1 & \text{SLA OK, niedopasowanie} \\ -5 & \text{naruszenie SLA, umiejętności OK} \\ -7 & \text{naruszenie SLA, niedopasowanie} \end{cases}",
            "book_ref": "📖  Czytaj §1.1 — Sygnał Nagrody i Hipoteza Nagrody",
            "code_ref": "🦀  `reward(state, action)` w `ch01_asp_dispatch.rs`",
        },
    },
}

# ── Colours ───────────────────────────────────────────────────────────────────
URGENCY_COLOR = {"Low": "#4CAF50", "Medium": "#FF9800", "High": "#F44336", "Critical": "#9C27B0"}

# ─────────────────────────────────────────────────────────────────────────────
def render(lang: str = "en"):
    t = THEORY[lang]

    # Which theory section to auto-expand (driven by session state)
    auto_expand = st.session_state.get("ch01_theory_focus", None)

    st.markdown(
        "## Chapter 01 — ASP Field Service Dispatch" if lang == "en"
        else "## Rozdział 01 — Dyspozycja ASP"
    )
    st.caption(
        "⚙️ Rust engine active — all RL computation in `rlvr_py`"
        if lang == "en"
        else "⚙️ Silnik Rust aktywny — całe obliczenia RL w `rlvr_py`"
    )

    # ── Sidebar controls ──────────────────────────────────────────────────────
    with st.sidebar:
        st.markdown("### ⚙️ Controls" if lang == "en" else "### ⚙️ Ustawienia")
        epsilon = st.slider(
            "ε (epsilon)" if lang == "en" else "ε (epsilon)",
            0.0, 1.0, 1.0, 0.05,
            help="1.0 = full exploration · 0.0 = exploit Q-table (all zeros in Ch01)" if lang == "en"
                 else "1,0 = pełna eksploracja · 0,0 = eksploatacja tablicy Q (zerowej w Rozdz.1)"
        )
        seed = st.number_input("Seed", 0, 9999, 42, 1)
        n_techs = st.slider(
            "Technicians" if lang == "en" else "Technicy", 2, 10, 5)
        n_orders = st.slider(
            "Work orders" if lang == "en" else "Zlecenia", 2, 15, 8)
        n_episodes = st.slider(
            "Episodes (learning curve)" if lang == "en" else "Epizody (krzywa uczenia)", 5, 100, 30)
        max_steps = st.slider(
            "Max steps / episode" if lang == "en" else "Max kroków / epizod", 5, 50, 20)
        run_btn = st.button(
            "▶ Run Episode" if lang == "en" else "▶ Uruchom epizod", type="primary")

    # Update theory focus when epsilon is moved
    if epsilon < 1.0:
        st.session_state["ch01_theory_focus"] = "epsilon_greedy"

    # ── Run episode via Rust engine ───────────────────────────────────────────
    if run_btn or "ch01_result" not in st.session_state:
        with st.spinner("Running Rust engine..." if lang == "en" else "Uruchamiam silnik Rust..."):
            raw = rlvr_py.run_ch01_episode(
                epsilon=epsilon,
                seed=int(seed),
                n_technicians=n_techs,
                n_orders=n_orders,
                max_steps=max_steps,
            )
        result = json.loads(raw)
        st.session_state["ch01_result"] = result
        st.session_state["ch01_params"] = dict(
            epsilon=epsilon, seed=seed, n_techs=n_techs,
            n_orders=n_orders, max_steps=max_steps)

        # Learning curve — run N episodes at decaying epsilon
        curve_gt = []
        with st.spinner("Computing learning curve..." if lang == "en" else "Obliczam krzywą uczenia..."):
            for ep in range(n_episodes):
                eps_ep = max(0.10, 1.0 * (0.99 ** ep))
                raw_ep = rlvr_py.run_ch01_episode(
                    epsilon=eps_ep, seed=int(seed) + ep,
                    n_technicians=n_techs, n_orders=n_orders, max_steps=max_steps)
                curve_gt.append(json.loads(raw_ep)["total_gt"])
        st.session_state["ch01_curve"] = curve_gt

    result  = st.session_state.get("ch01_result", {})
    steps   = result.get("steps", [])
    curve   = st.session_state.get("ch01_curve", [])

    if not steps:
        st.warning("No dispatch steps recorded." if lang == "en"
                   else "Brak zarejestrowanych kroków dyspozycji.")
        return

    # ── Metrics row ───────────────────────────────────────────────────────────
    total_gt  = result.get("total_gt", 0)
    n_sla     = result.get("n_sla_met", 0)
    n_skill   = result.get("n_skill_match", 0)
    n_explore = sum(1 for s in steps if s["was_random"])

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Total Gₜ" if lang == "en" else "Łączne Gₜ",          f"{total_gt:.1f}")
    c2.metric("Steps" if lang == "en" else "Kroki",                   len(steps))
    c3.metric("SLA Met" if lang == "en" else "SLA Spełnione",         f"{n_sla}/{len(steps)}")
    c4.metric("Skill Match" if lang == "en" else "Dop. Umiejętności", f"{n_skill}/{len(steps)}")
    c5.metric("Explored" if lang == "en" else "Eksploracja",          f"{n_explore}/{len(steps)}")

    st.markdown("---")

    # ── Three-column layout ───────────────────────────────────────────────────
    col_map, col_glass = st.columns([1.4, 1])

    # ── Panel 1: Warsaw dispatch map ──────────────────────────────────────────
    with col_map:
        st.markdown("### 🗺️ Warsaw Dispatch Map" if lang == "en"
                    else "### 🗺️ Mapa Dyspozycji Warszawa")

        # Collect unique techs and orders from steps
        techs_seen  = {}
        orders_seen = {}
        for s in steps:
            techs_seen[s["tech_id"]]   = (s["tech_lat"],  s["tech_lon"])
            orders_seen[s["order_id"]] = (s["order_lat"], s["order_lon"],
                                          s["order_urgency"], s["order_skill"])

        if HAS_PYDECK:
            import pydeck as pdk

            tech_data  = [{"lat": v[0], "lon": v[1], "id": k}
                          for k, v in techs_seen.items()]
            order_data = [{"lat": v[0], "lon": v[1], "urgency": v[2], "skill": v[3], "id": k}
                          for k, v in orders_seen.items()]
            line_data  = [{"s_lat": s["tech_lat"], "s_lon": s["tech_lon"],
                           "e_lat": s["order_lat"], "e_lon": s["order_lon"],
                           "color": [76,175,80,160] if s["sla_met"] else [244,67,54,160]}
                          for s in steps]

            layers = [
                pdk.Layer("ScatterplotLayer", tech_data,
                          get_position=["lon","lat"], get_radius=400,
                          get_fill_color=[33,150,243,200], pickable=True),
                pdk.Layer("ScatterplotLayer", order_data,
                          get_position=["lon","lat"], get_radius=300,
                          get_fill_color=[255,152,0,200], pickable=True),
                pdk.Layer("LineLayer", line_data,
                          get_source_position=["s_lon","s_lat"],
                          get_target_position=["e_lon","e_lat"],
                          get_color="color", get_width=3),
            ]
            view = pdk.ViewState(latitude=52.23, longitude=21.01, zoom=10, pitch=0)
            st.pydeck_chart(pdk.Deck(layers=layers, initial_view_state=view,
                                     tooltip={"text": "{id}"}))
        else:
            # Plotly fallback (map only, no RL logic)
            fig = go.Figure()
            for k, v in techs_seen.items():
                fig.add_trace(go.Scattermapbox(
                    lat=[v[0]], lon=[v[1]], mode="markers+text",
                    marker=dict(size=14, color="#2196F3"),
                    text=[f"T{k}"], textposition="top right", name=f"Tech {k}"))
            for k, v in orders_seen.items():
                col = URGENCY_COLOR.get(v[2], "#FF9800")
                fig.add_trace(go.Scattermapbox(
                    lat=[v[0]], lon=[v[1]], mode="markers+text",
                    marker=dict(size=10, color=col),
                    text=[f"O{k}"], textposition="top right", name=f"Order {k}"))
            for s in steps:
                lc = "green" if s["sla_met"] else "red"
                fig.add_trace(go.Scattermapbox(
                    lat=[s["tech_lat"], s["order_lat"]],
                    lon=[s["tech_lon"], s["order_lon"]],
                    mode="lines", line=dict(width=2, color=lc), showlegend=False))
            fig.update_layout(
                mapbox=dict(style="open-street-map",
                            center=dict(lat=52.23, lon=21.01), zoom=9),
                margin=dict(l=0,r=0,t=0,b=0), height=420)
            st.plotly_chart(fig, use_container_width=True)

        # ── Learning curve ────────────────────────────────────────────────────
        st.markdown("### 📈 Learning Curve — Gₜ per Episode" if lang == "en"
                    else "### 📈 Krzywa Uczenia — Gₜ na Epizod")
        st.caption(
            "Q-table is all zeros → curve fluctuates randomly. "
            "It climbs in Chapter 02 once Bellman updates activate."
            if lang == "en" else
            "Tablica Q jest zerowa → krzywa fluktuuje losowo. "
            "Wzrośnie w Rozdziale 2 po aktywacji aktualizacji Bellmana."
        )

        if curve:
            import numpy as np
            window = max(1, len(curve) // 5)
            rolling = [float(np.mean(curve[max(0,i-window):i+1]))
                       for i in range(len(curve))]
            fig2 = go.Figure()
            fig2.add_trace(go.Scatter(
                y=curve, mode="lines", name="Gₜ",
                line=dict(color="#90CAF9", width=1.5)))
            fig2.add_trace(go.Scatter(
                y=rolling, mode="lines", name="Rolling mean",
                line=dict(color="#2196F3", width=2.5, dash="dot")))
            fig2.add_hrect(y0=min(curve)-1, y1=0,
                           fillcolor="red", opacity=0.07, line_width=0)
            fig2.update_layout(
                xaxis_title="Episode", yaxis_title="Gₜ",
                height=260, margin=dict(l=0,r=0,t=10,b=0),
                legend=dict(orientation="h", y=1.1))
            st.plotly_chart(fig2, use_container_width=True)

    # ── Panel 2: Glass-Box ────────────────────────────────────────────────────
    with col_glass:
        st.markdown("### 🔬 Glass-Box Inspector" if lang == "en"
                    else "### 🔬 Inspektor Glass-Box")
        st.caption(
            "Every MDP step from the Rust engine — (Sₜ, Aₜ, Rₜ, Gₜ, ε)"
            if lang == "en"
            else "Każdy krok MDP z silnika Rust — (Sₜ, Aₜ, Rₜ, Gₜ, ε)"
        )

        for s in steps:
            r_col  = "#4CAF50" if s["reward"] > 0 else "#F44336"
            ex_tag = ("🎲 explore" if s["was_random"] else "🎯 exploit") if lang == "en" \
                     else ("🎲 eksplor." if s["was_random"] else "🎯 eksploit.")
            sla_tag = ("✅ SLA" if s["sla_met"] else "❌ SLA") 
            sk_tag  = ("✅ skill" if s["skill_match"] else "⚠️ skill")

            with st.expander(
                f"Step {s['step']+1}  |  T{s['tech_id']}→O{s['order_id']}  "
                f"|  Rₜ={s['reward']:+.0f}  |  Gₜ={s['gt']:.1f}  |  {ex_tag}",
                expanded=(s["step"] == 0)
            ):
                st.markdown(
                    f"**Sₜ** tech=T{s['tech_id']} `{s['tech_skill']}` "
                    f"({s['tech_lat']:.3f}, {s['tech_lon']:.3f})  \n"
                    f"&nbsp;&nbsp;&nbsp;&nbsp;order=O{s['order_id']} `{s['order_skill']}` "
                    f"`{s['order_urgency']}` ({s['order_lat']:.3f}, {s['order_lon']:.3f})"
                )
                st.markdown(
                    f"**Aₜ** assign T{s['tech_id']} → O{s['order_id']}  "
                    f"{sla_tag} {sk_tag}"
                )
                st.markdown(
                    f"**Rₜ** <span style='color:{r_col};font-weight:bold'>{s['reward']:+.1f}</span> &nbsp;"
                    f"**Gₜ** {s['gt']:.2f} &nbsp; **ε** {s['epsilon']:.3f}",
                    unsafe_allow_html=True
                )

        st.markdown("---")
        st.markdown(
            "**Bellman update** *(activates in Chapter 02)*"
            if lang == "en"
            else "**Aktualizacja Bellmana** *(aktywuje się w Rozdziale 02)*"
        )
        st.latex(r"Q(s,a) \leftarrow Q(s,a)+\alpha\!\left[R+\gamma\max_{a'}Q(s',a')-Q(s,a)\right]")
        st.caption(
            "Q-table is all zeros here — this equation fills it from Ch02 onward."
            if lang == "en"
            else "Tablica Q jest tu zerowa — to równanie wypełni ją od Rozdz. 02."
        )

    st.markdown("---")

    # ── Theory panel ─────────────────────────────────────────────────────────
    theory_label = "📖 Theory — Chapter 01" if lang == "en" else "📖 Teoria — Rozdział 01"
    with st.expander(theory_label, expanded=False):
        lang_note = (
            "Embedded theory anchored to the running demo. "
            "Each section maps to a specific Rust function."
            if lang == "en"
            else "Teoria osadzona w działającym demo. "
                 "Każda sekcja mapuje się na konkretną funkcję Rust."
        )
        st.caption(lang_note)

        theory_keys = ["mdp", "epsilon_greedy", "gt", "ndarray", "reward"]
        for key in theory_keys:
            section = t[key]
            should_expand = (auto_expand == key)
            with st.expander(section["title"], expanded=should_expand):
                st.markdown(section["summary"])
                st.latex(section["equation"])
                st.info(section["book_ref"])
                st.code(section["code_ref"], language="text")
