
//! Chapter 01 — ASP Field Service Dispatch (Warsaw)
//!
//! Book §1.1  MDP tuple (S,A,P,R,γ)   → AspState, AspAction, reward(), transition()
//! Book §1.1  ε-Greedy policy          → epsilon_greedy()
//! Book §1.1  Discounted return Gₜ     → discounted_return()
//! Book §1.2.1 ndarray Q-table         → Array2::<f64>::zeros(…) in AspEnvironment
//!
//! The Q-table is ALL ZEROS in Ch01 — intentionally untrained.
//! Chapter 02 introduces the Bellman update that fills it.

use ndarray::Array2;
use rand::Rng;
use serde::{Deserialize, Serialize};
use crate::rng::seeded_rng;

// ── Hyperparameters ──────────────────────────────────────────────────────────
pub const GAMMA:         f64 = 0.95;   // §1.1 discount factor
pub const EPSILON_INIT:  f64 = 1.0;    // fully exploratory at start
pub const EPSILON_DECAY: f64 = 0.99;   // per-episode decay
pub const MIN_EPSILON:   f64 = 0.10;   // exploration floor

const R_SLA_SKILL:    f64 =  10.0;  // SLA met + skill match
const R_SLA_NO_SKILL: f64 =   3.0;  // SLA met, wrong skill
const R_BREACH:       f64 =  -5.0;  // SLA breach
const R_SKILL_PEN:    f64 =  -2.0;  // extra penalty for skill mismatch

// Warsaw bounding box
const LAT_MIN: f64 = 52.10; const LAT_MAX: f64 = 52.35;
const LON_MIN: f64 = 20.85; const LON_MAX: f64 = 21.25;

// ── Domain types ─────────────────────────────────────────────────────────────
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum Skill { Hvac, Electrical, Plumbing, Network, General }

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum Urgency { Low, Medium, High, Critical }

impl std::fmt::Display for Skill {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        write!(f, "{:?}", self)
    }
}
impl std::fmt::Display for Urgency {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        write!(f, "{:?}", self)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Technician {
    pub id:        usize,
    pub skill:     Skill,
    pub lat:       f64,
    pub lon:       f64,
    pub available: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkOrder {
    pub id:             usize,
    pub required_skill: Skill,
    pub urgency:        Urgency,
    pub lat:            f64,
    pub lon:            f64,
    pub sla_hours:      f64,
}

/// Sₜ — the full observable world at time t  (§1.1)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AspState {
    pub technicians:    Vec<Technician>,
    pub pending_orders: Vec<WorkOrder>,
    pub step:           usize,
}

/// Aₜ — assign technicians[tech_idx] to pending_orders[order_idx]  (§1.1)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AspAction {
    pub tech_idx:  usize,
    pub order_idx: usize,
}

/// One recorded MDP step — serialized to Python for Glass-Box display
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StepRecord {
    pub step:          usize,
    pub tech_id:       usize,
    pub tech_skill:    String,
    pub tech_lat:      f64,
    pub tech_lon:      f64,
    pub order_id:      usize,
    pub order_skill:   String,
    pub order_urgency: String,
    pub order_lat:     f64,
    pub order_lon:     f64,
    pub reward:        f64,
    pub gt:            f64,      // §1.1 discounted return from this step onward
    pub epsilon:       f64,      // §1.1 ε at this step
    pub sla_met:       bool,
    pub skill_match:   bool,
    pub was_random:    bool,     // true = explored, false = exploited Q-table
}

/// Full episode result returned to Python
#[derive(Debug, Serialize, Deserialize)]
pub struct EpisodeResult {
    pub steps:         Vec<StepRecord>,
    pub total_gt:      f64,
    pub n_sla_met:     usize,
    pub n_skill_match: usize,
    pub epsilon_final: f64,
}

// ── Environment ──────────────────────────────────────────────────────────────
pub struct AspEnvironment {
    /// §1.2.1 ndarray Q-table — Array2 zeros = untrained; Ch02 fills this
    pub q_table:  Array2<f64>,
    pub n_techs:  usize,
    pub n_orders: usize,
}

impl AspEnvironment {
    pub fn new(n_techs: usize, n_orders: usize) -> Self {
        Self {
            q_table: Array2::<f64>::zeros((n_techs, n_orders)),
            n_techs,
            n_orders,
        }
    }

    /// Reset — generates a fresh Warsaw state deterministically from seed
    /// Determinism is the Markov property in action: same seed → same world
    pub fn reset(&self, seed: u64) -> AspState {
        let mut rng = seeded_rng(seed);
        let skills    = [Skill::Hvac, Skill::Electrical, Skill::Plumbing,
                         Skill::Network, Skill::General];
        let urgencies = [Urgency::Low, Urgency::Medium, Urgency::High, Urgency::Critical];
        let sla_map   = [24.0_f64, 8.0, 4.0, 1.0];

        let technicians = (0..self.n_techs).map(|id| {
            let si = rng.gen_range(0..5usize);
            Technician {
                id,
                skill: skills[si].clone(),
                lat: rng.gen_range(LAT_MIN..LAT_MAX),
                lon: rng.gen_range(LON_MIN..LON_MAX),
                available: true,
            }
        }).collect();

        let pending_orders = (0..self.n_orders).map(|id| {
            let si = rng.gen_range(0..5usize);
            let ui = rng.gen_range(0..4usize);
            WorkOrder {
                id,
                required_skill: skills[si].clone(),
                urgency: urgencies[ui].clone(),
                lat: rng.gen_range(LAT_MIN..LAT_MAX),
                lon: rng.gen_range(LON_MIN..LON_MAX),
                sla_hours: sla_map[ui],
            }
        }).collect();

        AspState { technicians, pending_orders, step: 0 }
    }
}

// ── R(s, a) — Reward function  (§1.1) ────────────────────────────────────────
/// Returns (reward, sla_met, skill_match)
/// Distance in degrees × 111 km/deg used as travel-time proxy
pub fn reward(state: &AspState, action: &AspAction) -> (f64, bool, bool) {
    let tech  = &state.technicians[action.tech_idx];
    let order = &state.pending_orders[action.order_idx];

    let skill_match = tech.skill == order.required_skill;
    let dist_km     = ((tech.lat - order.lat).powi(2)
                     + (tech.lon - order.lon).powi(2)).sqrt() * 111.0;
    // Assume average speed 60 km/h → hours = dist_km / 60
    let travel_h    = dist_km / 60.0;
    let sla_met     = travel_h <= order.sla_hours;

    let r = match (sla_met, skill_match) {
        (true,  true)  => R_SLA_SKILL,
        (true,  false) => R_SLA_NO_SKILL + R_SKILL_PEN,
        (false, true)  => R_BREACH,
        (false, false) => R_BREACH + R_SKILL_PEN,
    };
    (r, sla_met, skill_match)
}

// ── P(s'|s,a) — Transition function  (§1.1 Markov property) ─────────────────
/// Future depends ONLY on (s, a) — not on any history before t
pub fn transition(state: &AspState, action: &AspAction, step_seed: u64) -> AspState {
    let mut next = state.clone();
    // Technician dispatched → temporarily unavailable
    if action.tech_idx < next.technicians.len() {
        next.technicians[action.tech_idx].available = false;
    }
    // Work order fulfilled → remove from queue
    if action.order_idx < next.pending_orders.len() {
        next.pending_orders.remove(action.order_idx);
    }
    next.step += 1;

    // Stochastic new arrival with prob 0.5 (Poisson process, §samplers::poisson)
    let mut rng = seeded_rng(step_seed);
    if rng.gen::<f64>() < 0.5 && next.pending_orders.len() < 8 {
        let skills    = [Skill::Hvac, Skill::Electrical, Skill::Plumbing,
                         Skill::Network, Skill::General];
        let urgencies = [Urgency::Low, Urgency::Medium, Urgency::High, Urgency::Critical];
        let sla_map   = [24.0_f64, 8.0, 4.0, 1.0];
        let ui = rng.gen_range(0..4usize);
        next.pending_orders.push(WorkOrder {
            id:             100 + state.step,
            required_skill: skills[rng.gen_range(0..5)].clone(),
            urgency:        urgencies[ui].clone(),
            lat:            rng.gen_range(LAT_MIN..LAT_MAX),
            lon:            rng.gen_range(LON_MIN..LON_MAX),
            sla_hours:      sla_map[ui],
        });
    }
    next
}

// ── ε-Greedy policy  (§1.1) ──────────────────────────────────────────────────
/// With prob ε: random (explore). With prob 1-ε: argmax Q[tech_idx,order_idx] (exploit).
/// When Q-table is all zeros, exploit = random (agent is blind — see Ch02).
pub fn epsilon_greedy(
    q_table: &Array2<f64>,
    state:   &AspState,
    epsilon:  f64,
    rng:     &mut impl Rng,
) -> (AspAction, bool) {
    let avail: Vec<usize> = state.technicians.iter()
        .enumerate().filter(|(_, t)| t.available).map(|(i, _)| i).collect();

    if avail.is_empty() || state.pending_orders.is_empty() {
        return (AspAction { tech_idx: 0, order_idx: 0 }, true);
    }

    if rng.gen::<f64>() < epsilon {
        // Explore — uniform random over available (tech, order) pairs
        let ti = avail[rng.gen_range(0..avail.len())];
        let oi = rng.gen_range(0..state.pending_orders.len());
        (AspAction { tech_idx: ti, order_idx: oi }, true)
    } else {
        // Exploit — argmax Q[ti, oi]
        let mut best    = f64::NEG_INFINITY;
        let mut best_ti = avail[0];
        let mut best_oi = 0usize;
        for &ti in &avail {
            for oi in 0..state.pending_orders.len() {
                let q = if ti < q_table.nrows() && oi < q_table.ncols() {
                    q_table[[ti, oi]]
                } else { 0.0 };
                if q > best { best = q; best_ti = ti; best_oi = oi; }
            }
        }
        (AspAction { tech_idx: best_ti, order_idx: best_oi }, false)
    }
}

// ── Gₜ = Σ γᵏ Rₜ₊ₖ  (§1.1) ──────────────────────────────────────────────────
/// Computed backwards from episode end for numerical efficiency
pub fn discounted_return(rewards: &[f64], gamma: f64) -> Vec<f64> {
    let mut gt      = vec![0.0f64; rewards.len()];
    let mut running = 0.0f64;
    for k in (0..rewards.len()).rev() {
        running = rewards[k] + gamma * running;
        gt[k]   = running;
    }
    gt
}

// ── Episode runner ────────────────────────────────────────────────────────────
pub fn run_episode(
    env:       &AspEnvironment,
    epsilon:   f64,
    seed:      u64,
    max_steps: usize,
) -> EpisodeResult {
    let mut state   = env.reset(seed);
    let mut rng     = seeded_rng(seed.wrapping_add(7919));
    let mut eps     = epsilon;
    let mut records: Vec<StepRecord> = Vec::new();
    let mut rewards: Vec<f64>        = Vec::new();

    for step in 0..max_steps {
        // Ch01 simplified model: all technicians reset available each step
        state.technicians.iter_mut().for_each(|t| t.available = true);
        if state.pending_orders.is_empty() { break; }

        let (action, was_random) = epsilon_greedy(&env.q_table, &state, eps, &mut rng);
        let (r, sla_met, skill_match) = reward(&state, &action);

        let tech  = &state.technicians[action.tech_idx];
        let order = &state.pending_orders[action.order_idx];

        records.push(StepRecord {
            step,
            tech_id:       tech.id,
            tech_skill:    format!("{}", tech.skill),
            tech_lat:      tech.lat,
            tech_lon:      tech.lon,
            order_id:      order.id,
            order_skill:   format!("{}", order.required_skill),
            order_urgency: format!("{}", order.urgency),
            order_lat:     order.lat,
            order_lon:     order.lon,
            reward:        r,
            gt:            0.0,   // filled after backward pass
            epsilon:       eps,
            sla_met,
            skill_match,
            was_random,
        });
        rewards.push(r);

        state = transition(&state, &action, seed.wrapping_add(step as u64));
        eps = (eps * EPSILON_DECAY).max(MIN_EPSILON);
    }

    // Backward pass — fill Gₜ for every recorded step
    let gt_vals = discounted_return(&rewards, GAMMA);
    for (i, rec) in records.iter_mut().enumerate() {
        rec.gt = gt_vals[i];
    }

    let total_gt      = gt_vals.first().copied().unwrap_or(0.0);
    let n_sla_met     = records.iter().filter(|r| r.sla_met).count();
    let n_skill_match = records.iter().filter(|r| r.skill_match).count();

    EpisodeResult {
        steps: records,
        total_gt,
        n_sla_met,
        n_skill_match,
        epsilon_final: eps,
    }
}

// ── Tests ─────────────────────────────────────────────────────────────────────
#[cfg(test)]
mod tests {
    use super::*;

    /// §1.1 Markov property: same seed → identical initial state
    #[test]
    fn reset_is_deterministic() {
        let env = AspEnvironment::new(5, 5);
        let s1  = env.reset(42);
        let s2  = env.reset(42);
        assert_eq!(s1.technicians[0].lat, s2.technicians[0].lat);
        assert_eq!(s1.pending_orders[0].sla_hours, s2.pending_orders[0].sla_hours);
    }

    /// §1.2.1 ndarray Q-table: initialized to zeros (untrained)
    #[test]
    fn q_table_starts_zero() {
        let env = AspEnvironment::new(5, 5);
        assert!(env.q_table.iter().all(|&v| v == 0.0),
                "Q-table must start at zeros (untrained in Ch01)");
    }

    /// §1.1 Reward: skill match + SLA met → maximum reward +10
    #[test]
    fn reward_skill_and_sla() {
        let env = AspEnvironment::new(1, 1);
        let mut s = env.reset(1);
        s.technicians[0].skill             = Skill::Hvac;
        s.technicians[0].lat               = 52.23;
        s.technicians[0].lon               = 21.01;
        s.pending_orders[0].required_skill = Skill::Hvac;
        s.pending_orders[0].lat            = 52.23;  // same location → 0 km travel
        s.pending_orders[0].lon            = 21.01;
        s.pending_orders[0].sla_hours      = 24.0;
        let (r, sla, skill) = reward(&s, &AspAction { tech_idx: 0, order_idx: 0 });
        assert!(sla,   "SLA should be met (0 km travel)");
        assert!(skill, "Skill should match (both Hvac)");
        assert_eq!(r, 10.0);
    }

    /// §1.1 Reward: breach + skill mismatch → minimum reward -7
    #[test]
    fn reward_breach_and_mismatch() {
        let env = AspEnvironment::new(1, 1);
        let mut s = env.reset(2);
        s.technicians[0].skill             = Skill::Hvac;
        s.technicians[0].lat               = 52.10;
        s.technicians[0].lon               = 20.85;
        s.pending_orders[0].required_skill = Skill::Electrical;
        s.pending_orders[0].lat            = 52.35;  // far away
        s.pending_orders[0].lon            = 21.25;
        s.pending_orders[0].sla_hours      = 0.01;   // 36 seconds SLA → breach
        let (r, sla, skill) = reward(&s, &AspAction { tech_idx: 0, order_idx: 0 });
        assert!(!sla,   "SLA should be breached");
        assert!(!skill, "Skill should mismatch");
        assert_eq!(r, -7.0);
    }

    /// §1.1 Gₜ: verify backward discounting formula
    #[test]
    fn discounted_return_correct() {
        let gt = discounted_return(&[1.0, 1.0, 1.0], 0.5);
        assert!((gt[0] - 1.75).abs() < 1e-9, "G0=1+0.5+0.25=1.75");
        assert!((gt[1] - 1.50).abs() < 1e-9, "G1=1+0.5=1.50");
        assert!((gt[2] - 1.00).abs() < 1e-9, "G2=1.00");
    }

    /// §1.1 Markov property: same (s,a) → same next state regardless of history
    #[test]
    fn transition_markov_property() {
        let env = AspEnvironment::new(5, 5);
        let s   = env.reset(42);
        let a   = AspAction { tech_idx: 0, order_idx: 0 };
        let s1  = transition(&s, &a, 100);
        let s2  = transition(&s, &a, 100);
        assert_eq!(s1.step, s2.step);
        assert_eq!(s1.pending_orders.len(), s2.pending_orders.len());
    }

    /// Full episode runs without panic
    #[test]
    fn episode_runs_to_completion() {
        let env = AspEnvironment::new(5, 5);
        let res = run_episode(&env, 1.0, 42, 20);
        assert!(!res.steps.is_empty());
        assert!(res.steps.iter().all(|s| s.gt.is_finite()));
    }
}
