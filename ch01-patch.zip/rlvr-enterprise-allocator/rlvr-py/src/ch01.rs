//! PyO3 binding for Ch01 — serialises EpisodeResult as JSON string
use pyo3::prelude::*;
use rlvr_core::ch01_asp_dispatch::{AspEnvironment, run_episode};

/// Run one ASP dispatch episode and return JSON string.
/// Python side: import json; data = json.loads(run_ch01_episode(...))
#[pyfunction]
#[pyo3(signature = (epsilon=1.0, seed=42, n_technicians=5, n_orders=5, max_steps=20))]
pub fn run_ch01_episode(
    epsilon:       f64,
    seed:          u64,
    n_technicians: usize,
    n_orders:      usize,
    max_steps:     usize,
) -> PyResult<String> {
    let env    = AspEnvironment::new(n_technicians, n_orders);
    let result = run_episode(&env, epsilon, seed, max_steps);
    serde_json::to_string(&result)
        .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))
}
