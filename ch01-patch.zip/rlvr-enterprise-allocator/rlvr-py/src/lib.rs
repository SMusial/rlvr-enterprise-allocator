use pyo3::prelude::*;
mod ch01;

#[pymodule]
fn rlvr_py(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(ch01::run_ch01_episode, m)?)?;
    m.add_function(wrap_pyfunction!(ping, m)?)?;
    Ok(())
}

#[pyfunction]
fn ping() -> &'static str { "rlvr_py ok" }
